import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { Toaster } from '@/components/ui/sonner'
import './index.css'
import App from './App.tsx'

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
    <Toaster 
      position="bottom-right"
      toastOptions={{
        style: {
          background: 'hsl(260 15% 8%)',
          border: '1px solid rgba(255,255,255,0.1)',
          color: 'white',
        },
      }}
    />
  </StrictMode>,
)
