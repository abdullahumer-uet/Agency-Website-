import { useEffect, useRef, useState } from 'react';
import { BookOpen, Monitor, Sofa, Gem } from 'lucide-react';

const Aesthetics = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);
  const [activeStyle, setActiveStyle] = useState(0);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const aestheticStyles = [
    {
      id: 0,
      name: 'Dark Academia',
      tagline: 'Intellectual & Moody',
      description: 'Vintage library atmosphere with earthy tones, oil paintings, and scholarly vibes. Perfect for those who find beauty in classical knowledge and moody aesthetics.',
      image: '/images/dark-academia.jpg',
      icon: BookOpen,
      colors: ['#8B7355', '#4A4A4A', '#2C1810', '#D4C4A8'],
      features: ['Classical portraits', 'Earthy palettes', 'Vintage textures', 'Scholarly themes'],
    },
    {
      id: 1,
      name: 'Vaporwave',
      tagline: 'Neon & Digital-Native',
      description: 'Retro-futuristic digital art with neon gradients, glitch effects, and 80s nostalgia. For the digital natives who grew up with the internet.',
      image: '/images/vaporwave.jpg',
      icon: Monitor,
      colors: ['#FF00FF', '#00FFFF', '#FF0080', '#8000FF'],
      features: ['Neon gradients', 'Glitch aesthetics', 'Retro wave', 'Digital art'],
    },
    {
      id: 2,
      name: 'Cozy Maximalism',
      tagline: 'Eclectic & Layered',
      description: 'Warm, inviting spaces with eclectic patterns, layered textures, and bohemian vibes. More is more - embrace the beautiful chaos.',
      image: '/images/cozy-maximalism.jpg',
      icon: Sofa,
      colors: ['#D4A574', '#8B4513', '#CD853F', '#DEB887'],
      features: ['Eclectic patterns', 'Layered textures', 'Warm tones', 'Bohemian vibes'],
    },
    {
      id: 3,
      name: 'Minimalist Luxury',
      tagline: 'Clean & Sophisticated',
      description: 'Abstract geometric shapes with soft neutral tones and clean lines. Sophisticated elegance for the modern minimalist.',
      image: '/images/minimalist-luxury.jpg',
      icon: Gem,
      colors: ['#F5F5DC', '#D4C4A8', '#C0C0C0', '#FFFFFF'],
      features: ['Geometric shapes', 'Neutral palettes', 'Clean lines', 'Modern design'],
    },
  ];

  const currentStyle = aestheticStyles[activeStyle];

  return (
    <section
      id="aesthetics"
      ref={sectionRef}
      className="relative py-24 md:py-32 overflow-hidden"
    >
      {/* Background Elements */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-white/10 to-transparent" />
        <div className="absolute bottom-0 right-0 w-[600px] h-[600px] bg-neon-pink/5 rounded-full blur-[200px]" />
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className={`text-center mb-16 md:mb-20 transition-all duration-700 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
          <span className="inline-block px-4 py-1.5 rounded-full glass text-sm font-medium text-neon-cyan mb-4">
            Our Aesthetics
          </span>
          <h2 className="font-display font-bold text-3xl sm:text-4xl md:text-5xl lg:text-6xl text-white mb-6">
            Find Your <span className="text-gradient">Style</span>
          </h2>
          <p className="max-w-2xl mx-auto text-base sm:text-lg text-white/60">
            From Dark Academia to Vaporwave, explore our curated collection of 
            trending internet aesthetics designed for every vibe.
          </p>
        </div>

        {/* Aesthetic Selector */}
        <div className={`flex flex-wrap justify-center gap-3 mb-12 transition-all duration-700 delay-200 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
          {aestheticStyles.map((style, index) => (
            <button
              key={style.id}
              onClick={() => setActiveStyle(index)}
              className={`flex items-center gap-2 px-4 sm:px-6 py-3 rounded-full transition-all duration-300 ${
                activeStyle === index
                  ? 'bg-gradient-to-r from-neon-purple to-neon-pink text-white shadow-glow-purple'
                  : 'glass text-white/70 hover:text-white hover:bg-white/10'
              }`}
            >
              <style.icon className="w-4 h-4" />
              <span className="text-sm font-medium">{style.name}</span>
            </button>
          ))}
        </div>

        {/* Main Content */}
        <div className={`grid lg:grid-cols-2 gap-8 lg:gap-12 items-center transition-all duration-700 delay-300 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
          {/* Image */}
          <div className="relative group">
            <div className="relative rounded-3xl overflow-hidden aspect-[3/4] max-w-md mx-auto lg:max-w-none">
              <img
                src={currentStyle.image}
                alt={currentStyle.name}
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-background/60 via-transparent to-transparent" />
              
              {/* Overlay Info */}
              <div className="absolute bottom-0 left-0 right-0 p-6">
                <div className="glass rounded-2xl p-4">
                  <h3 className="font-display font-semibold text-xl text-white mb-1">
                    {currentStyle.name}
                  </h3>
                  <p className="text-sm text-white/70">{currentStyle.tagline}</p>
                </div>
              </div>
            </div>
            
            {/* Glow Effect */}
            <div 
              className="absolute -inset-4 rounded-3xl blur-2xl -z-10 transition-colors duration-500 opacity-30"
              style={{ background: `linear-gradient(135deg, ${currentStyle.colors[0]}, ${currentStyle.colors[1]})` }}
            />
          </div>

          {/* Content */}
          <div className="space-y-6">
            <div>
              <h3 className="font-display font-bold text-2xl sm:text-3xl md:text-4xl text-white mb-4">
                {currentStyle.name}
              </h3>
              <p className="text-lg text-neon-purple mb-2">{currentStyle.tagline}</p>
              <p className="text-white/60 leading-relaxed">
                {currentStyle.description}
              </p>
            </div>

            {/* Color Palette */}
            <div>
              <p className="text-sm text-white/50 mb-3">Color Palette</p>
              <div className="flex gap-3">
                {currentStyle.colors.map((color, index) => (
                  <div
                    key={index}
                    className="w-12 h-12 rounded-xl border-2 border-white/10 transition-transform duration-300 hover:scale-110"
                    style={{ backgroundColor: color }}
                    title={color}
                  />
                ))}
              </div>
            </div>

            {/* Features */}
            <div>
              <p className="text-sm text-white/50 mb-3">Key Features</p>
              <div className="flex flex-wrap gap-2">
                {currentStyle.features.map((feature) => (
                  <span
                    key={feature}
                    className="px-4 py-2 rounded-full glass text-sm text-white/80"
                  >
                    {feature}
                  </span>
                ))}
              </div>
            </div>

            {/* Navigation Dots */}
            <div className="flex gap-2 pt-4">
              {aestheticStyles.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setActiveStyle(index)}
                  className={`w-2 h-2 rounded-full transition-all duration-300 ${
                    activeStyle === index
                      ? 'w-8 bg-gradient-to-r from-neon-purple to-neon-pink'
                      : 'bg-white/30 hover:bg-white/50'
                  }`}
                />
              ))}
            </div>
          </div>
        </div>

        {/* Style Cards Grid */}
        <div className={`grid grid-cols-2 lg:grid-cols-4 gap-4 mt-16 transition-all duration-700 delay-500 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
          {aestheticStyles.map((style, index) => (
            <button
              key={style.id}
              onClick={() => setActiveStyle(index)}
              className={`relative group rounded-2xl overflow-hidden aspect-square transition-all duration-300 ${
                activeStyle === index ? 'ring-2 ring-neon-purple ring-offset-2 ring-offset-background' : ''
              }`}
            >
              <img
                src={style.image}
                alt={style.name}
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-background/90 via-background/40 to-transparent" />
              <div className="absolute bottom-0 left-0 right-0 p-4">
                <div className="flex items-center gap-2">
                  <style.icon className="w-4 h-4 text-white" />
                  <span className="font-medium text-sm text-white">{style.name}</span>
                </div>
              </div>
            </button>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Aesthetics;
