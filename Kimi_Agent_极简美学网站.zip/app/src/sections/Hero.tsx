import { useEffect, useRef } from 'react';
import { ArrowRight, Zap, Palette, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';

const Hero = () => {
  const heroRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!heroRef.current) return;
      const { clientX, clientY } = e;
      const { innerWidth, innerHeight } = window;
      const x = (clientX / innerWidth - 0.5) * 20;
      const y = (clientY / innerHeight - 0.5) * 20;
      
      const elements = heroRef.current.querySelectorAll('.parallax');
      elements.forEach((el) => {
        (el as HTMLElement).style.transform = `translate(${x}px, ${y}px)`;
      });
    };

    window.addEventListener('mousemove', handleMouseMove, { passive: true });
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  const scrollToSection = (href: string) => {
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section
      id="home"
      ref={heroRef}
      className="relative min-h-screen flex items-center justify-center overflow-hidden"
    >
      {/* Background Image */}
      <div className="absolute inset-0">
        <img
          src="/images/hero-bg.jpg"
          alt="Aesthetic Room"
          className="w-full h-full object-cover opacity-40"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-background/60 via-background/40 to-background" />
      </div>

      {/* Animated Background Elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {/* Floating Orbs */}
        <div className="parallax absolute top-1/4 left-1/4 w-64 h-64 bg-neon-purple/20 rounded-full blur-[100px] animate-pulse-slow" />
        <div className="parallax absolute bottom-1/4 right-1/4 w-96 h-96 bg-neon-pink/15 rounded-full blur-[120px] animate-pulse-slow" style={{ animationDelay: '2s' }} />
        <div className="parallax absolute top-1/2 right-1/3 w-48 h-48 bg-neon-cyan/10 rounded-full blur-[80px] animate-pulse-slow" style={{ animationDelay: '1s' }} />
        
        {/* Grid Pattern */}
        <div 
          className="absolute inset-0 opacity-[0.03]"
          style={{
            backgroundImage: `linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px),
                              linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px)`,
            backgroundSize: '50px 50px',
          }}
        />
      </div>

      {/* Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="text-center">
          {/* Badge */}
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass mb-8 animate-slide-up">
            <Sparkles className="w-4 h-4 text-neon-purple" />
            <span className="text-sm font-medium text-white/80">GenZ Aesthetic Revolution</span>
          </div>

          {/* Main Heading */}
          <h1 className="font-display font-bold text-4xl sm:text-5xl md:text-6xl lg:text-7xl xl:text-8xl text-white leading-tight mb-6 animate-slide-up" style={{ animationDelay: '100ms' }}>
            Curate Your
            <br />
            <span className="text-gradient">Perfect Vibe</span>
          </h1>

          {/* Subheading */}
          <p className="max-w-2xl mx-auto text-base sm:text-lg md:text-xl text-white/60 mb-10 animate-slide-up" style={{ animationDelay: '200ms' }}>
            AI-powered wall art for the new generation. From Dark Academia to Vaporwave, 
            we create trendy, customizable decor that speaks your aesthetic language.
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-16 animate-slide-up" style={{ animationDelay: '300ms' }}>
            <Button
              onClick={() => scrollToSection('#products')}
              size="lg"
              className="bg-gradient-to-r from-neon-purple to-neon-pink hover:from-neon-pink hover:to-neon-purple text-white font-semibold px-8 py-6 text-base rounded-xl transition-all duration-300 hover:shadow-glow-purple group"
            >
              Explore Collection
              <ArrowRight className="ml-2 w-5 h-5 transition-transform duration-300 group-hover:translate-x-1" />
            </Button>
            <Button
              onClick={() => scrollToSection('#about')}
              variant="outline"
              size="lg"
              className="border-white/20 text-white hover:bg-white/10 font-semibold px-8 py-6 text-base rounded-xl transition-all duration-300"
            >
              Learn More
            </Button>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-3 gap-4 sm:gap-8 max-w-2xl mx-auto animate-slide-up" style={{ animationDelay: '400ms' }}>
            <div className="glass rounded-2xl p-4 sm:p-6">
              <div className="flex items-center justify-center gap-2 mb-2">
                <Zap className="w-4 h-4 sm:w-5 sm:h-5 text-neon-cyan" />
                <span className="font-display font-bold text-xl sm:text-2xl md:text-3xl text-white">50+</span>
              </div>
              <p className="text-xs sm:text-sm text-white/50">Unique Designs</p>
            </div>
            <div className="glass rounded-2xl p-4 sm:p-6">
              <div className="flex items-center justify-center gap-2 mb-2">
                <Palette className="w-4 h-4 sm:w-5 sm:h-5 text-neon-pink" />
                <span className="font-display font-bold text-xl sm:text-2xl md:text-3xl text-white">4</span>
              </div>
              <p className="text-xs sm:text-sm text-white/50">Aesthetic Styles</p>
            </div>
            <div className="glass rounded-2xl p-4 sm:p-6">
              <div className="flex items-center justify-center gap-2 mb-2">
                <Sparkles className="w-4 h-4 sm:w-5 sm:h-5 text-neon-purple" />
                <span className="font-display font-bold text-xl sm:text-2xl md:text-3xl text-white">100%</span>
              </div>
              <p className="text-xs sm:text-sm text-white/50">AI Generated</p>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Gradient */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-background to-transparent" />
    </section>
  );
};

export default Hero;
