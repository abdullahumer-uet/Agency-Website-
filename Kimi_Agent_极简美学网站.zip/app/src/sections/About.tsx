import { useEffect, useRef, useState } from 'react';
import { Target, Lightbulb, Heart, Rocket } from 'lucide-react';

const About = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const features = [
    {
      icon: Target,
      title: 'Our Mission',
      description: 'To democratize trendy interior decor for Pakistani youth by making high-quality, aesthetic art accessible and affordable through AI technology.',
      color: 'from-neon-purple to-neon-pink',
    },
    {
      icon: Lightbulb,
      title: 'The Idea',
      description: 'We bridge the gap between technology and interior design. We are not just selling posters; we are selling a "vibe" that resonates with your personality.',
      color: 'from-neon-cyan to-neon-blue',
    },
    {
      icon: Heart,
      title: 'Made for GenZ',
      description: 'Designed by young creatives for young creatives. We understand the aesthetic language of our generation - from Dark Academia to Vaporwave.',
      color: 'from-neon-pink to-rose-400',
    },
    {
      icon: Rocket,
      title: 'The Future',
      description: 'Starting with digital art and prints, scaling to laser-cut wood and 3D decor. We are building the future of personalized home aesthetics.',
      color: 'from-amber-400 to-orange-500',
    },
  ];

  return (
    <section
      id="about"
      ref={sectionRef}
      className="relative py-24 md:py-32 overflow-hidden"
    >
      {/* Background Elements */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-white/10 to-transparent" />
        <div className="absolute top-1/3 right-0 w-96 h-96 bg-neon-purple/5 rounded-full blur-[150px]" />
        <div className="absolute bottom-1/3 left-0 w-96 h-96 bg-neon-pink/5 rounded-full blur-[150px]" />
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className={`text-center mb-16 md:mb-20 transition-all duration-700 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
          <span className="inline-block px-4 py-1.5 rounded-full glass text-sm font-medium text-neon-purple mb-4">
            About Us
          </span>
          <h2 className="font-display font-bold text-3xl sm:text-4xl md:text-5xl lg:text-6xl text-white mb-6">
            We Are <span className="text-gradient">Aesthetic Vibes</span>
          </h2>
          <p className="max-w-3xl mx-auto text-base sm:text-lg text-white/60">
            A student-led venture established to disrupt the local home decor market. 
            We leverage Generative AI to create trendy, "GenZ" aesthetic art that transforms spaces.
          </p>
        </div>

        {/* Image + Content Grid */}
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center mb-20">
          {/* Image */}
          <div className={`relative transition-all duration-700 delay-200 ${isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-8'}`}>
            <div className="relative rounded-3xl overflow-hidden">
              <img
                src="/images/team.jpg"
                alt="Our Creative Team"
                className="w-full aspect-video object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-background/60 to-transparent" />
            </div>
            {/* Floating Badge */}
            <div className="absolute -bottom-6 -right-6 glass rounded-2xl p-4 sm:p-6">
              <div className="text-center">
                <span className="font-display font-bold text-2xl sm:text-3xl text-gradient">2</span>
                <p className="text-xs sm:text-sm text-white/60 mt-1">Co-Founders</p>
              </div>
            </div>
            {/* Glow Effect */}
            <div className="absolute -inset-4 bg-gradient-to-r from-neon-purple/20 to-neon-pink/20 rounded-3xl blur-2xl -z-10" />
          </div>

          {/* Content */}
          <div className={`space-y-6 transition-all duration-700 delay-300 ${isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-8'}`}>
            <h3 className="font-display font-semibold text-2xl sm:text-3xl text-white">
              Born in Islamabad, Made for <span className="text-neon-purple">You</span>
            </h3>
            <p className="text-white/60 leading-relaxed">
              We started with a simple observation: trendy decor is either imported and expensive, 
              or locally available but outdated. As university students ourselves, we knew there had 
              to be a better way.
            </p>
            <p className="text-white/60 leading-relaxed">
              By combining AI technology with an understanding of GenZ aesthetics, we have created 
              a service that offers global trends at local student prices. Our print-on-demand model 
              means zero waste and infinite possibilities.
            </p>
            
            {/* Stats Row */}
            <div className="flex flex-wrap gap-4 pt-4">
              <div className="glass rounded-xl px-5 py-3">
                <span className="font-display font-bold text-xl text-white">1,000 PKR</span>
                <p className="text-xs text-white/50">Starting Investment</p>
              </div>
              <div className="glass rounded-xl px-5 py-3">
                <span className="font-display font-bold text-xl text-white">100%</span>
                <p className="text-xs text-white/50">Customizable</p>
              </div>
              <div className="glass rounded-xl px-5 py-3">
                <span className="font-display font-bold text-xl text-white">0</span>
                <p className="text-xs text-white/50">Inventory Risk</p>
              </div>
            </div>
          </div>
        </div>

        {/* Features Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
          {features.map((feature, index) => (
            <div
              key={feature.title}
              className={`group relative glass rounded-2xl p-6 hover-lift transition-all duration-700 ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
              }`}
              style={{ transitionDelay: `${400 + index * 100}ms` }}
            >
              {/* Icon */}
              <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${feature.color} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300`}>
                <feature.icon className="w-6 h-6 text-white" />
              </div>
              
              {/* Content */}
              <h4 className="font-display font-semibold text-lg text-white mb-2">
                {feature.title}
              </h4>
              <p className="text-sm text-white/60 leading-relaxed">
                {feature.description}
              </p>

              {/* Hover Glow */}
              <div className={`absolute inset-0 rounded-2xl bg-gradient-to-br ${feature.color} opacity-0 group-hover:opacity-10 transition-opacity duration-300 -z-10`} />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default About;
