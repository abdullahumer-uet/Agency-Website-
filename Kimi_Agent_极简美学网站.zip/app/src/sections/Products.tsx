import { useEffect, useRef, useState } from 'react';
import { Download, Printer, Wand2, Check, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';

const Products = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const products = [
    {
      icon: Download,
      name: 'Digital Download',
      price: '150 - 300',
      currency: 'PKR',
      description: 'High-resolution digital file delivered instantly via email or WhatsApp. Print it yourself or use it digitally.',
      features: [
        'Instant delivery',
        '4K resolution',
        'Multiple formats (JPG, PNG)',
        'Unlimited personal use',
        'Perfect for digital frames',
      ],
      popular: false,
      gradient: 'from-neon-cyan to-neon-blue',
    },
    {
      icon: Printer,
      name: 'A4 Premium Print',
      price: '150 - 200',
      currency: 'PKR',
      description: 'High-quality glossy or matte print on premium paper. Perfect for your dorm room or apartment.',
      features: [
        'Glossy or matte finish',
        'Premium 300gsm paper',
        'Vibrant colors',
        'Ready to frame',
        'Protective packaging',
      ],
      popular: true,
      gradient: 'from-neon-purple to-neon-pink',
    },
    {
      icon: Wand2,
      name: 'Custom Commission',
      price: '500',
      currency: 'PKR+',
      description: 'Have a specific vibe in mind? We will generate a unique custom piece based on your prompt.',
      features: [
        'Fully custom design',
        'Based on your prompt',
        'Multiple revisions',
        'Exclusive artwork',
        'Priority support',
      ],
      popular: false,
      gradient: 'from-amber-400 to-orange-500',
    },
  ];

  const scrollToContact = () => {
    const element = document.querySelector('#contact');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section
      id="products"
      ref={sectionRef}
      className="relative py-24 md:py-32 overflow-hidden"
    >
      {/* Background Elements */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-white/10 to-transparent" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-neon-purple/5 rounded-full blur-[200px]" />
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className={`text-center mb-16 md:mb-20 transition-all duration-700 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
          <span className="inline-block px-4 py-1.5 rounded-full glass text-sm font-medium text-neon-pink mb-4">
            Our Products
          </span>
          <h2 className="font-display font-bold text-3xl sm:text-4xl md:text-5xl lg:text-6xl text-white mb-6">
            Choose Your <span className="text-gradient">Vibe</span>
          </h2>
          <p className="max-w-2xl mx-auto text-base sm:text-lg text-white/60">
            From instant digital downloads to premium physical prints, 
            we have got the perfect option for your aesthetic needs.
          </p>
        </div>

        {/* Products Grid */}
        <div className="grid md:grid-cols-3 gap-6 lg:gap-8 mb-16">
          {products.map((product, index) => (
            <div
              key={product.name}
              className={`relative group transition-all duration-700 ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
              }`}
              style={{ transitionDelay: `${200 + index * 100}ms` }}
            >
              {/* Popular Badge */}
              {product.popular && (
                <div className="absolute -top-4 left-1/2 -translate-x-1/2 z-10">
                  <span className="inline-block px-4 py-1 rounded-full bg-gradient-to-r from-neon-purple to-neon-pink text-white text-xs font-semibold">
                    Most Popular
                  </span>
                </div>
              )}

              <div className={`relative h-full glass rounded-3xl p-6 sm:p-8 border border-white/10 hover:border-white/20 transition-all duration-300 ${product.popular ? 'scale-105' : ''}`}>
                {/* Icon */}
                <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${product.gradient} flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300`}>
                  <product.icon className="w-7 h-7 text-white" />
                </div>

                {/* Product Name */}
                <h3 className="font-display font-semibold text-xl text-white mb-2">
                  {product.name}
                </h3>

                {/* Price */}
                <div className="mb-4">
                  <span className="font-display font-bold text-3xl sm:text-4xl text-white">
                    {product.price}
                  </span>
                  <span className="text-white/50 ml-1">{product.currency}</span>
                </div>

                {/* Description */}
                <p className="text-sm text-white/60 mb-6 leading-relaxed">
                  {product.description}
                </p>

                {/* Features */}
                <ul className="space-y-3 mb-8">
                  {product.features.map((feature) => (
                    <li key={feature} className="flex items-start gap-3">
                      <div className={`w-5 h-5 rounded-full bg-gradient-to-br ${product.gradient} flex items-center justify-center flex-shrink-0 mt-0.5`}>
                        <Check className="w-3 h-3 text-white" />
                      </div>
                      <span className="text-sm text-white/70">{feature}</span>
                    </li>
                  ))}
                </ul>

                {/* CTA Button */}
                <Button
                  onClick={scrollToContact}
                  className={`w-full bg-gradient-to-r ${product.gradient} hover:opacity-90 text-white font-semibold py-5 rounded-xl transition-all duration-300 group/btn`}
                >
                  Get Started
                  <ArrowRight className="ml-2 w-4 h-4 transition-transform duration-300 group-hover/btn:translate-x-1" />
                </Button>

                {/* Glow Effect */}
                <div className={`absolute inset-0 rounded-3xl bg-gradient-to-br ${product.gradient} opacity-0 group-hover:opacity-10 transition-opacity duration-300 -z-10 blur-xl`} />
              </div>
            </div>
          ))}
        </div>

        {/* Gallery Preview */}
        <div className={`relative rounded-3xl overflow-hidden transition-all duration-700 delay-500 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
          <img
            src="/images/gallery-wall.jpg"
            alt="Gallery Wall Preview"
            className="w-full aspect-[21/9] object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-background/80 via-background/40 to-transparent" />
          <div className="absolute inset-0 flex items-center">
            <div className="px-8 sm:px-12 lg:px-16 max-w-lg">
              <h3 className="font-display font-semibold text-2xl sm:text-3xl text-white mb-3">
                Transform Your Space
              </h3>
              <p className="text-white/70 mb-6">
                Create a gallery wall that tells your story. Mix and match styles for a truly unique aesthetic.
              </p>
              <Button
                onClick={scrollToContact}
                variant="outline"
                className="border-white/30 text-white hover:bg-white/10"
              >
                Start Your Project
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Products;
